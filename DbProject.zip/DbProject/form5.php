<?php
$host = "localhost";
$user = "root";
$pass ="";
$dbname ="hostel_ms";

$conn = mysqli_connect($host, $user, $pass, $dbname);

if($conn){
    echo("connected.");
}
else{
die("connection failed.");
}
 

$vistor_name=$_POST['vistor_name'];
$in_time=$_POST['in_time'];
$out_time =$_POST['out_time'];
$date =$_POST['date'];
$s_Id=$_POST['sid'];

    $sql = "INSERT INTO `visitor`(`visitor_Name`, `in_Time`, `out_Time`, `date_`, `s_Id`)
     VALUES ('$vistor_name','$in_time','$out_time','$date','$s_Id' )";
    
    $reasult=mysqli_query($conn,$sql);
    if($reasult){
    
      echo"<h1>Data Inserted</h1>";
    }
    else{
        echo("not inserted.");
    }


?>