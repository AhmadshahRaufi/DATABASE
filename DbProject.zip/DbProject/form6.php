<?php
$host = "localhost";
$user = "root";
$pass ="";
$dbname ="Hostel_MS";

$conn = mysqli_connect($host, $user, $pass, $dbname);

if($conn){
    echo("connected.");
}
else{
die("connection failed.");
}
 

$id =$_POST['furniture_type'];
$h_no =$_POST['furniture_type']; 
$r_no =$_POST['furniture_type']; 

    $sql = "INSERT INTO `furniture`(`furniture_type`) VALUES ('$id' )";
    
    $reasult=mysqli_query($conn,$sql);
    if($reasult){
    
        echo"<h1>Data Inserted</h1>";
    }
    else{
        echo("not inserted.");
    }


?>