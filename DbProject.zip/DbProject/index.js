 

     let b2= document.getElementById('b22');

    let frm2 = document.querySelector('.form2');

    let b3= document.getElementById('b33');

    let frm3 = document.querySelector('.form3');

    let b4= document.getElementById('b44');

    let frm4 = document.querySelector('.form4');

    let b5= document.getElementById('b55');

    let frm5 = document.querySelector('.form5');
  
 
    
    let b1 = document.getElementById('b11');
    let frm1 = document.getElementById('f1');
    
    b1.addEventListener('click', function(event) {
      event.preventDefault(); // Prevent the default behavior of the anchor tag
    
      frm1.style.display = "block";
      document.querySelector('.mainPage').style.display = "none";
    });
    
    b2.addEventListener('click',function(){
        frm2.style.display = "block";
        document.querySelector(".form1").style.display = "none";
        document.querySelector(".form3").style.display = "none";
        document.querySelector(".form4").style.display = "none";
        document.querySelector(".form5").style.display = "none";
         
    });
    
    b3.addEventListener('click',function(){
        frm3.style.display = "block";
        document.querySelector(".form1").style.display = "none";
        document.querySelector(".form2").style.display = "none";
        document.querySelector(".form4").style.display = "none";
        document.querySelector(".form5").style.display = "none";
         
    });
    b4.addEventListener('click',function(){
        frm4.style.display = "block";
        document.querySelector(".form1").style.display = "none";
        document.querySelector(".form3").style.display = "none";
        document.querySelector(".form2").style.display = "none";
        document.querySelector(".form5").style.display = "none";
    });
    b5.addEventListener('click',function(){
        frm5.style.display = "block";
        document.querySelector(".form1").style.display = "none";
        document.querySelector(".form3").style.display = "none";
        document.querySelector(".form4").style.display = "none";
        document.querySelector(".form2").style.display = "none";
         
    });*/