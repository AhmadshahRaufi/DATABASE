<?php
    $email = $_POST['email'];
    $password= $_POST['password'];

    $con = new mysqli("localhost","root","","practice");
    if($con->connect_error){
        die("fieled to t connect :".$con->connect_error);

    }
    else{

        echo" <h>connected</h>";  
$stat= $con->prepare("select * from login where email=?");
$stat->bind_param("s",$email);
$stat->execute();
$stat_result=$stat->get_result();
if($stat_result->num_rows>0) {
    $data=$stat_result->fetch_assoc();
    if($data['password']===$password){
            
        header("Location:next.html");
    }else{
        ///
      echo"<h1>invalid email or paasword</h2>";
        }
    }
        else{
            echo"<h2>invalide email and password</h2>";
        }  
    }
 

 
?>