<?php
$host = "localhost";
$user = "root";
$pass ="";
$dbname ="hostel_ms";

$conn = mysqli_connect($host, $user, $pass, $dbname);

if($conn){
    echo("connected.");
}
else{
die("connection failed.");
}
 

$fname =$_POST['fisrt_name'];
$Lname =$_POST['last_name'];
$mNo =$_POST['mobile_no'];
$sql="INSERT INTO `supervisor`(`first_Name`, `last_Name`, `mobile_No` ) VALUES
 ('$fname','$Lname','$mNo')";
    
    $reasult=mysqli_query($conn,$sql);
    if($reasult){
    
        echo "<h1>Data Inserted</h1>";
    }
    else{
        echo("not inserted.");
    }


?>