<?php
$host = "localhost";
$user = "root";
$pass ="";
$dbname ="practice";

$conn = mysqli_connect($host, $user, $pass, $dbname);

if($conn){
    echo("connected.");
}
else{
die("connection failed.");
}
 

$id =$_POST['id'];
$name =$_POST['name'];
$location =$_POST['location'];
$usage =$_POST['usage'];

    $sql = "INSERT INTO `equipment`(`id`, `name`, `location`, `usage`) VALUES ('$id','$name','$location','$usage')";
    
    $reasult=mysqli_query($conn,$sql);
    if($reasult){
    
        echo"<h1>Data Inserted</h1>";
    }
    else{
        echo("not inserted.");
    }


?>