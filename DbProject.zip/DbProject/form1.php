<?php
$host = "localhost";
$user = "root";
$pass ="";
$dbname ="hostel_ms";

$conn = mysqli_connect($host, $user, $pass, $dbname);

if($conn){
    echo("connected.");
}
else{
die("connection failed.");
}
 

$H_N =$_POST['Hostel_name'];
$n_r =$_POST['No_room'];
$location =$_POST['No_student'];

    $sql = "INSERT INTO `hostel`(`hostel_Name`, `no_of_Rooms`, `no_of_Students`) 
    VALUES ('$H_N','$n_r','$location')";
    
    $reasult=mysqli_query($conn,$sql);
    if($reasult){
        echo"<h1>Data Inserted</h1>";
    }
    else{
        echo("not inserted.");
    }


?>